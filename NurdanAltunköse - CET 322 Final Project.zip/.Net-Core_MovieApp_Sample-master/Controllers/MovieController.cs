using Microsoft.AspNetCore.Mvc;

namespace NetCore_MovieApp.Controllers
{
    public class MovieController:Controller
    {
        public IActionResult Index()
        {
            // TODO: Your code here
            return View();
        }

        public IActionResult Create()
        {
            // TODO: Your code here
            return View();
        }

        public IActionResult Details()
        {
            // TODO: Your code here
            return View();
        }
        
        
        
    }
}