# .Net-Core_MovieApp_Sample
.Net Core örnek basit bir web uygulaması.
Uygulamamızda static oluşturulan film ve kategori listesi listeleme ve görüntüleme işlemleri yapılmaktadır.
* .net core web projesi oluşturulması.
* startup.cs ayarlamaları ve manuel olarak mvc ayarlamaları.
* Basit düzeyde Model,View ve Controller yapılarının Kurulması.
* Main Page , List , Details Page İşlemleri.
* ViewComponent Kullanımı Örneği
Ekran Görüntüleri : 

![Image description](https://github.com/salihseker/.Net-Core_MovieApp_Sample/blob/master/Docs/Screenshot_1.png)
![Image description](https://github.com/salihseker/.Net-Core_MovieApp_Sample/blob/master/Docs/Screenshot_3.png)
![Image description](https://github.com/salihseker/.Net-Core_MovieApp_Sample/blob/master/Docs/Screenshot_4.png)

